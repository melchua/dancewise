# frozen_string_literal: true

require 'test_helper'

class GatheringEventTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

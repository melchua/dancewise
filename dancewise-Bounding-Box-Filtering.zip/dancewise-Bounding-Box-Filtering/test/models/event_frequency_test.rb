# frozen_string_literal: true

require 'test_helper'

class EventFrequencyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

# frozen_string_literal: true

module EventTypesHelper
end
